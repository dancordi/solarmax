<?php
#
# Some user variables...
#
$lat					= 50.0000; #Latitude (+ to N)
$lng					= -1.0000; #Longitude (+ to E)
$path_to_pv				= '/path/to/your/install/'; #with trailing slash
$curl_url 				= 'http://<curl-endpoint>';
$dashboard_url 			= 'http://<url-to-your-dashboard>';
$email_to_addresses		= array('user1@domain.com','user2@domain.com');
$email_from 			= 'no-reply@domain.com';
$USERNAME				= 'YOU_SYSTEM_NAME'; #configured by you

#Probably don't need to touch these, unless your home network is not 192.168.1.x
$V_SM_IPADDR 			= "192.168.1.123";
$V_SM_IPPORT 			= "12345";
$V_SM_DEVICE_ADDR 		= "1";
$V_SM_COMM_TIMEOUT 		= 5; # seconds
